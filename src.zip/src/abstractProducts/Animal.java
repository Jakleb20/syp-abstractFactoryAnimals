package org.example.abstractProducts;

public interface Animal {
    String getPhoto();
    String getName();
    String getHabitat();
    String getFood();
}

