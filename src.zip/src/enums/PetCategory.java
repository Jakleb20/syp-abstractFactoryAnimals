package org.example.enums;

public enum PetCategory 
{
    HUND, KATZE, VOGEL
}
