package org.example.enums;

public enum AnimalCategory {
    HAUSTIERE, WILDTIERE
}
