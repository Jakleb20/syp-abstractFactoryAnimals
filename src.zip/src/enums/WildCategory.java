package org.example.enums;

public enum WildCategory 
{
    LÖWE, ELEFANT
}
